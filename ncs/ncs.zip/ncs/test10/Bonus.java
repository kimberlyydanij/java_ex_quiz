package ncs.test10;

interface Bonus{
	public void incentive(int pay);
}

