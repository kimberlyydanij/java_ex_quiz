package ncs.test06;

public class ExceptionTest {

	public static void main(String[] args) {
		int data = 2;
		double sum = Calculator.getSum(data);
		
		System.out.println("결과값 : " + sum);

	}//end main()

}//end class
