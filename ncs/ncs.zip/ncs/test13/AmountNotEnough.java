package ncs.test13;

public class AmountNotEnough extends Exception {
	
	public AmountNotEnough(String message) {
		super(message);
	}
}

